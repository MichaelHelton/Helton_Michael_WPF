/*
Mike Helton
06/22/2014
Conditionals_Personal.
*/


//Finding out if we will have practice today
var outsideWeather = prompt("Is it Clear or Raining outside?");

//if it is clear we will practice
//if it is raining we will not practice
if(outsideWeather == "Clear"){
    //writing if to the console
    console.log("We will have practice today.");
}else{
    //writing else to console
    console.log("We will not have practice today.")
}