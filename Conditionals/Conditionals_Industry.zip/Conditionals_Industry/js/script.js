/*
 Mike Helton
 06/22/2014
 Conditionals_Industry.
 */

//How many pages
var numOfPages = prompt("How many pages do you want on your website?");
console.log(numOfPages + " pages in website.");
//writing the if statement
if (numOfPages > 10){
    //code for true statement
    console.log("Price increases above 10 pages.");
    //code for false statement
}else{
    console.log("Price is XX amount for 10 pages.");
}

//How many images
var numOfImages = prompt("How many images will be inserted into your website?");
console.log(numOfImages + " images inserted into website.")
//writing if statement
if(numOfImages > 10){
    //code for true statement
    console.log("Price increases above 10 images.");
    //code for false statement
}else{
    console.log("Price includes 10 images.");
}