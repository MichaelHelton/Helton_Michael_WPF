/*
Mike Helton
06/12/2014
Expressions_Personal
*/
//Finding out the square footage of a room
//The width of the room in feet
var roomWidth = prompt ("What is the width of your room");
console.log(roomWidth);

//The length of the room in feet
var roomLength = prompt ("What is the length of your room");
console.log(roomLength);

//The square footage
answer = roomWidth * roomLength +" square feet";
console.log(answer);

//Alerting the customer with the square footage
alert(roomWidth * roomLength +" square feet");
document.write(answer);



